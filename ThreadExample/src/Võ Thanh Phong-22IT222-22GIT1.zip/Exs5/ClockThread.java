package com.example.clock;

import javafx.scene.control.Label;
import javafx.application.Platform;
import java.util.Calendar;
import java.util.TimeZone;

public class ClockThread extends Thread {
    private Label label;
    private TimeZone timeZone;

    public ClockThread(Label label, TimeZone timeZone) {
        this.label = label;
        this.timeZone = timeZone;
    }

    @Override
    public void run() {
        while(true) {
            Calendar calendar = Calendar.getInstance(timeZone);
            String time = String.format("%02d:%02d:%02d", calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE), calendar.get(Calendar.SECOND));
            Platform.runLater(() -> label.setText(time));
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    public void setTimeZone(TimeZone timeZone) {
        this.timeZone = timeZone;
    }
}
