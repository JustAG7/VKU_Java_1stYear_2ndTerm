package com.example.clock;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;

import java.util.TimeZone;

public class Controller {
    @FXML
    private ComboBox<String> timeZones = new ComboBox<>();
    @FXML
    private Label label = new Label();
    private ClockThread clockThread;
    public void initialize() {
        ObservableList<String> timeZonesList = FXCollections.observableArrayList();
        for (String id : TimeZone.getAvailableIDs()) {
            timeZonesList.add(id);
        }
        timeZones.setItems(timeZonesList);
        timeZones.setValue("Europe/Amsterdam");

        clockThread = new ClockThread(label, TimeZone.getTimeZone(timeZones.getValue()));
        clockThread.setDaemon(true);
        clockThread.start();

        timeZones.setOnAction(event -> {
            clockThread.setTimeZone(TimeZone.getTimeZone(timeZones.getValue()));
        });

        timeZones.setOnKeyPressed(event -> {
            String keyPressed = event.getText();
            if (keyPressed != null && keyPressed.length() > 0) {
                ObservableList<String> filteredItems = FXCollections.observableArrayList();
                for (String timeZone : timeZonesList) {
                    if (timeZone.toLowerCase().startsWith(keyPressed.toLowerCase())) {
                        filteredItems.add(timeZone);
                    }
                }
                if (!filteredItems.isEmpty()) {
                    timeZones.setItems(filteredItems);
                    timeZones.show();
                }
            }
        });
        timeZones.setOnKeyReleased(event -> {
            if (event.getCode() == KeyCode.BACK_SPACE && (timeZones.getEditor().getText() == null || timeZones.getEditor().getText().isEmpty())) {
                timeZones.setItems(timeZonesList);
                timeZones.hide();
                timeZones.show();
            }
        });
    }
}
